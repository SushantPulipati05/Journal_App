# Dev environment for the journal server. Load it with:  . .\dev.ps1
# (the leading dot-and-space matters: it keeps the variables in your session)
$env:DATABASE_URL = "postgres://journal:journal@localhost:5433/journal?sslmode=disable"
$env:JWT_SECRET = "dev-only-secret-change-me-in-production-0123456789"
$env:DOCKER_HOST = "npipe:////./pipe/dockerDesktopLinuxEngine"
$env:TESTCONTAINERS_RYUK_DISABLED = "true"
Write-Host "Dev environment loaded."
